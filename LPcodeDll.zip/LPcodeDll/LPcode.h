#pragma once
#ifdef  __cplusplus
#define EXTERNC extern "C"
#else
#define EXTERNC
#endif //  __cplusplus

#ifdef DLL_IMPORT
#define HEAD EXTERNC __declspec(dllimport)
#else
#define HEAD EXTERNC __declspec(dllexport)
#endif // DLL_IMPORT 

#define CallingConvention  _cdecl


HEAD const int* CallingConvention GetLPCodeArray(char const*  ctr, int nEcc = 0, int rownum= -101, int nScale = 3);

HEAD  int CallingConvention GetLens(int& nRowNum, int& nColNum);