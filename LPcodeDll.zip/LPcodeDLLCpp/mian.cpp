#include<iostream>
#define DLL_IMPORT
#include"../LPcodeDll/LPcode.h"
#pragma comment(lib,"../bin/LPcodeDll.lib")
int main(int argc, char* argv[])
{
	const int *a = GetLPCodeArray("abcdefwtawwtwqouaooosotw");
	int b = 0;
	int c = 0;
	int lens = GetLens(b,c);
	printf("%d\n", lens);
	for (int i = 0; i < lens; i++)
	{
		std::cout << a[i] ;
	}
	std::cout << std::endl;
	std::cout << b << " _ " << c <<std:: endl;
	return 0;
}