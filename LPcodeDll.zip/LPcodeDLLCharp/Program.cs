﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;



namespace LPcodeDLLCharp
{
    internal class Program
    {
        [DllImport("LPcodeDll.dll")]
        public static extern IntPtr GetLPCodeArray(string ctr, int nEcc, int nRownum, int nScale);

        [DllImport("LPcodeDll.dll")]
        public static extern int GetLens(ref int nRowNum, ref int nColNum);
        static void Main(string[] args)
        {
            int a = 0;
            int b = 0;
            IntPtr intPtr = GetLPCodeArray("asd", 0, -101, 3);
            int c = GetLens(ref a, ref b);
            int[] nums = new int[c];
            Marshal.Copy(intPtr, nums, 0, c);
            Console.WriteLine(intPtr);
            Console.WriteLine(c);
            for (int i = 0; i < nums.Length; i++)
            {
                if (nums[i] == 2)
                {
                    Console.WriteLine();
                    continue;
                }
                Console.Write(nums[i]);
            }
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.ReadKey();
        }
    }
}
